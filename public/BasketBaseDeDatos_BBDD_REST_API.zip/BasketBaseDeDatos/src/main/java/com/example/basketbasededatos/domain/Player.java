package com.example.basketbasededatos.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.*;

@Getter
@Setter
@ToString

@NoArgsConstructor

@Entity
public class Player {
    @Id private String name;
    private double height;
//    private int dorsalNumber;
    private int basketScore;
//    private int numberRebounds;
//    private int numAssists;

    @ManyToOne private Team team;

    public Player(String name, double height, int basketScore, Team team) {
        this.name = name;
        this.height = height;
        this.basketScore = basketScore;
        this.team = team;
    }

/*
    @Override
    public String toString() {
        return "Player{" +
                "name='" + name + '\'' +
                ", basketScore=" + basketScore +
                ", team=" + team +
                '}' + System.lineSeparator();
    }
 */
}
