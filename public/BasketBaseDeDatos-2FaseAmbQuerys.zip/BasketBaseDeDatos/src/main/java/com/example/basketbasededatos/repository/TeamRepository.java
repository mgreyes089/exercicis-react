package com.example.basketbasededatos.repository;

import com.example.basketbasededatos.domain.Team;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepository extends JpaRepository<Team,String> {

}
