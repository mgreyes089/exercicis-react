package com.example.basketbasededatos.rest;

import com.example.basketbasededatos.domain.Team;
import com.example.basketbasededatos.repository.TeamRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TeamRestController {
    private TeamRepository teamRepository;

    public TeamRestController(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }

    @PostMapping("/teams")
    public void createTeam(@RequestBody Team team) {
        teamRepository.save(team);
    }

    @GetMapping("/teams")
    public List<Team> getAllTeams() {
        return teamRepository.findAll();
    }

    @GetMapping("/teams/byCity/{city}")
    public List<Team> getTeamsByCity (@PathVariable String city){
        return teamRepository.findByCity(city);
    }

}
