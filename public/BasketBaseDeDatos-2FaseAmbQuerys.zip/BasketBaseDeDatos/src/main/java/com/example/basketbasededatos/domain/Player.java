package com.example.basketbasededatos.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
public class Player {
    @Id
    private String name;
    private double height;
    //    private int dorsalNumber;
    private int basketScore;
//    private int numberRebounds;
//    private int numAssists;

    @ManyToOne
    private Team team;




}
