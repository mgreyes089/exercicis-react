package com.example.basketbasededatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasketBaseDeDatosApplicationTests {

    @Test
    void contextLoads() {
    }

}
