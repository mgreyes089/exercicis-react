package com.example.basketbasededatos;

import com.example.basketbasededatos.domain.Player;
import com.example.basketbasededatos.domain.Team;
import com.example.basketbasededatos.repository.PlayerRepository;
import com.example.basketbasededatos.repository.TeamRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.sql.SQLOutput;
import java.util.List;

@SpringBootApplication
public class BasketBaseDeDatosApplication implements CommandLineRunner {

    private TeamRepository teamRepository;
    private PlayerRepository playerRepository;

    public BasketBaseDeDatosApplication(TeamRepository teamRepository, PlayerRepository playerRepository) {
        this.teamRepository = teamRepository;
        this.playerRepository = playerRepository;
    }


    public static void main(String[] args) {
        SpringApplication.run(BasketBaseDeDatosApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Team barça = new Team("barça", "Barcelona");
        teamRepository.save(barça);
        Team madrid = new Team("madrid", "Madrid");
        teamRepository.save(madrid);

        Player player1 = new Player("Nuria", 1.95, 100, madrid);
        playerRepository.save(player1);
        Player player2 = new Player("Jose", 2.20, 4, barça);
        playerRepository.save(player2);
        Player player3 = new Player("Moises", 2.00,200, madrid);
        playerRepository.save(player3);
        Player player4 = new Player("Alfons", 1.90,1, barça);
        playerRepository.save(player4);


        List<Player> topPlayers = playerRepository.findByBasketScoreGreaterThan(100);

        System.out.println("Show topPlayers List");
        for (Player p : topPlayers) {
            System.out.println();
            System.out.println(p);
            System.out.println();
        }


        List<Player> playersByCity = playerRepository.findByTeamCity("Barcelona");
        System.out.println("Show Players by City List");
        for (Player p : playersByCity) {
            System.out.println();
            System.out.println(p);
            System.out.println();
        }

        List<Player> playersSortedByHeight = playerRepository.findByOrderByHeightDesc();
        System.out.println("Show Sorted Players by Height");
        for (Player p : playersSortedByHeight) {
            System.out.println();
            System.out.println(p);
            System.out.println();
        }
    }

}
