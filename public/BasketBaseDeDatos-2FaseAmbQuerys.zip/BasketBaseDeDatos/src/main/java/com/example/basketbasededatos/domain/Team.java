package com.example.basketbasededatos.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

@Entity
public class Team {
    @Id String name;
    String city;
    private static int MAX_NUMBERS_OF_PLAYERS=20;

}
