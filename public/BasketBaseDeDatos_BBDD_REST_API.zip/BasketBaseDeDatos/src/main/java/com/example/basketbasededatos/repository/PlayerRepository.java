package com.example.basketbasededatos.repository;

import com.example.basketbasededatos.domain.Player;
import com.example.basketbasededatos.domain.Team;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PlayerRepository extends JpaRepository<Player,String> {
    List<Player> findByBasketScoreGreaterThan(int score);

    List<Player> findByTeamCity(String city);

    List<Player> findByOrderByHeightDesc();
}
