package com.example.basketbasededatos;

import com.example.basketbasededatos.domain.Player;
import com.example.basketbasededatos.domain.Team;
import com.example.basketbasededatos.repository.PlayerRepository;
import com.example.basketbasededatos.repository.TeamRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class BasketBaseDeDatosApplication implements CommandLineRunner {

    private TeamRepository teamRepository;
    private PlayerRepository playerRepository;

    public BasketBaseDeDatosApplication(TeamRepository teamRepository, PlayerRepository playerRepository) {
        this.teamRepository = teamRepository;
        this.playerRepository = playerRepository;
    }


    public static void main(String[] args) {
        SpringApplication.run(BasketBaseDeDatosApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Team barça = new Team("barça", "Barcelona");
        teamRepository.save(barça);
        Team madrid = new Team("madrid", "Madrid");
        teamRepository.save(madrid);

        Player player1 = new Player("Nuria",1.6, 100,madrid);
        playerRepository.save(player1);
        Player player2 = new Player("Jose",2.1, 540,barça);
        playerRepository.save(player2);
        Player player3 = new Player("Moises",2.2, 200,madrid);
        playerRepository.save(player3);
        Player player4 = new Player("Alfons",1.85, 1,barça);
        playerRepository.save(player4);

        List<Player> topPlayers = playerRepository.findByBasketScoreGreaterThan(100);
        System.out.println("Show top players");
        for (Player p : topPlayers) {
            System.out.println(p);
            System.out.println();
        }

        List<Player> playersByCity = playerRepository.findByTeamCity("Barcelona");
        System.out.println("Show players of the city: ");
        for (Player p : playersByCity) {
            System.out.println(p);
            System.out.println();
        }

        List<Player> playersSortedByHeight = playerRepository.findByOrderByHeightDesc();
        System.out.println("Show sorted players by height: ");
        for (Player p : playersSortedByHeight) {
            System.out.println(p);
            System.out.println();
        }

    }
}
